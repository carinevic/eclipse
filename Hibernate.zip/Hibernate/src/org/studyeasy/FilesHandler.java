package org.studyeasy;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.studyeasy.hibernate.DAO.FilesDAO;

import com.sun.xml.bind.v2.schemagen.xmlschema.List;


@WebServlet("/FilesHandler")
public class FilesHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;
public String path ="c/images/";
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		String action =request.getParameter("action");
		switch(action) {
		case"filesUpload":
			filesUpload(request, response);
		break;
		
		case"updateInformation":
			updateInformation(request, response);
			break;
		case"listingImages":
			listingImages(request, response);
			break;
		default:
			request.getRequestDispatcher("index.jsp").forward(request,  response);
		}
		
		}
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		String action =request.getParameter("action");
		switch(action) {
		case"listingImages":
			listingImages(request, response);
			break;
		case"viewImage":
			viewImage(request, response);
			break;
			
		case"DeleteImage":
			DeleteImage(request, response);
			break;
		
		default:
			request.getRequestDispatcher("index.jsp").forward(request,  response);
		}
		
		}
	
	
	
	private void DeleteImage(HttpServletRequest request, HttpServletResponse response) {
		int fileId =Integer.parseInt(request.getParameter("fileId"));
		Files file = new FilesDAO().getFile(fileId);
		new FilesDAO().deleteFile(fileId);
	
		
	}


	private void viewImage(HttpServletRequest request, HttpServletResponse response) {
		int fileId =Integer.parseInt(request.getParameter("fileId");
		Files file = new FilesDAO().getFile(fileId);
		request.setAttribute("file", file);
		request.setAttribute("path", path);
		request.getRequestDispatcher("viewimages.jsp");
	}


	private void listingImages(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		List<Files> files = new FilesDAO().listFIles();
		request.setAttribute("files", files);
		request.setAttribute("path", path);
		request.getRequestDispatcher("listFiles.jsp").forward(request, response);
		
	}

private void updateInformation(HttpServletRequest request, HttpServletResponse response) {
	int fileId =Integer.parseInt(request.getParameter("fileId"));
	String label = request.getParameter("label");
	String Caption = request.getParameter("Caption");
	String Filename = request.getParameter("fileName");
		Files file = new Files(fileId, Filename, label, Caption);
		new FilesDAO().updateInformation(fileId, label, Caption);
		listingImages(request, response);
	}
	private void filesUpload(HttpServletRequest request, HttpServletResponse response) {
		ServletFileUpload upload = new ServletFileUpload(new DiskFileItemFactory());
		
		try {
		List<FileItem>images = upload.parseRequest(request);
	     for(FileItem image: images) {
			String name = image.getName();
			try{name= name.substring(name.lastIndexOf("\\")+1);} catch(Exception e) {}
			System.out.println(name);
			File file = new File(path+name);
			if(!file.exists()) {
			new FilesDAO().addFileDetails(new Files(name));
			images.write(file);
	     }
	     }
	}catch(Exception e) {
		e.printStackTrace();
	}
}
}